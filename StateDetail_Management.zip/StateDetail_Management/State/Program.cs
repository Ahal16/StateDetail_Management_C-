﻿using System;
using System.Collections.Generic;

namespace Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            List<State> states = new List<State>();
            StateDetails stateDetails = new StateDetails();

            while (true)
            {
                Console.WriteLine("Menu:");
                Console.WriteLine("1. Add State");
                Console.WriteLine("2. Display All States");
                Console.WriteLine("3. Search State by Area Code");
                Console.WriteLine("4. Change Population");
                Console.WriteLine("5. Change Chief Minister");
                Console.WriteLine("6. Display Total Number of States");
                Console.WriteLine("7. Display Most Populated State");
                Console.WriteLine("8. Exit");
                Console.Write("Choose an option: ");

                if (!int.TryParse(Console.ReadLine(), out int choice))
                {
                    Console.WriteLine("Invalid input, please enter a number.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        try
                        {
                            Console.Write("Enter State Name: ");
                            string name = Console.ReadLine();
                            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("State name cannot be empty.");

                            Console.Write("Enter Capital: ");
                            string capital = Console.ReadLine();
                            if (string.IsNullOrWhiteSpace(capital)) throw new ArgumentException("Capital cannot be empty.");

                            Console.Write("Enter Population: ");
                            if (!int.TryParse(Console.ReadLine(), out int population) || population <= 0)
                                throw new ArgumentException("Population must be a positive integer.");

                            Console.Write("Enter Chief Minister: ");
                            string chiefMinister = Console.ReadLine();
                            if (string.IsNullOrWhiteSpace(chiefMinister)) throw new ArgumentException("Chief Minister cannot be empty.");

                            Console.Write("Enter Area Code: ");
                            string areaCode = Console.ReadLine();
                            if (string.IsNullOrWhiteSpace(areaCode)) throw new ArgumentException("Area code cannot be empty.");

                            State state = new State(name, capital, population, chiefMinister, areaCode);
                            stateDetails.AddState(states, state);
                            Console.WriteLine("State added successfully.");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error: {ex.Message}");
                        }
                        break;

                    case 2:
                        stateDetails.DisplayAllStates(states);
                        break;

                    case 3:
                        Console.Write("Enter Area Code to Search: ");
                        string searchAreaCode = Console.ReadLine();
                        var foundState = stateDetails.SearchStateByAreaCode(states, searchAreaCode);
                        if (foundState != null)
                        {
                            Console.WriteLine($"Found State: {foundState.Name}");
                        }
                        else
                        {
                            Console.WriteLine("State not found.");
                        }
                        break;

                    case 4:
                        Console.Write("Enter Area Code to Change Population: ");
                        string areaCodeToChangePopulation = Console.ReadLine();
                        var stateToChangePopulation = stateDetails.SearchStateByAreaCode(states, areaCodeToChangePopulation);
                        if (stateToChangePopulation != null)
                        {
                            Console.Write("Enter New Population: ");
                            if (!int.TryParse(Console.ReadLine(), out int newPopulation) || newPopulation <= 0)
                            {
                                Console.WriteLine("Population must be a positive integer.");
                                break;
                            }
                            stateDetails.ChangePopulation(stateToChangePopulation, newPopulation);
                        }
                        else
                        {
                            Console.WriteLine("State not found.");
                        }
                        break;

                    case 5:
                        Console.Write("Enter Area Code to Change Chief Minister: ");
                        string areaCodeToChangeMinister = Console.ReadLine();
                        var stateToChangeMinister = stateDetails.SearchStateByAreaCode(states, areaCodeToChangeMinister);
                        if (stateToChangeMinister != null)
                        {
                            Console.Write("Enter New Chief Minister: ");
                            string newChiefMinister = Console.ReadLine();
                            if (string.IsNullOrWhiteSpace(newChiefMinister))
                            {
                                Console.WriteLine("Chief Minister cannot be empty.");
                                break;
                            }
                            stateDetails.ChangeChiefMinister(stateToChangeMinister, newChiefMinister);
                        }
                        else
                        {
                            Console.WriteLine("State not found.");
                        }
                        break;

                    case 6:
                        stateDetails.DisplayTotalStates();
                        break;

                    case 7:
                        try
                        {
                            State.DisplayMostPopulatedState(states);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error: {ex.Message}");
                        }
                        break;

                    case 8:
                        return;

                    default:
                        Console.WriteLine("Invalid option, please try again.");
                        break;
                }
            }
        }
    }
}
