﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;

public class StateDetails : Idetails
{
    private readonly string connectionString = ConfigurationManager.ConnectionStrings["MyConnectionString"].ConnectionString;

    public void DisplayAllStates(List<State> states)
    {
        if (states.Count == 0)
        {
            Console.WriteLine("No states available.");
            return;
        }

        foreach (var state in states)
        {
            Console.WriteLine($"Name: {state.Name}, Capital: {state.Capital}, Population: {state.Population}, Chief Minister: {state.ChiefMinister}, Area Code: {state.AreaCode}");
        }
    }

    public State SearchStateByAreaCode(List<State> states, string areaCode)
    {
        return states.Find(state => state.AreaCode.Equals(areaCode, StringComparison.OrdinalIgnoreCase));
    }

    public void AddState(List<State> states, State state)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            string query = "INSERT INTO States (Name, Capital, Population, ChiefMinister, AreaCode) VALUES (@Name, @Capital, @Population, @ChiefMinister, @AreaCode)";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Name", state.Name);
                cmd.Parameters.AddWithValue("@Capital", state.Capital);
                cmd.Parameters.AddWithValue("@Population", state.Population);
                cmd.Parameters.AddWithValue("@ChiefMinister", state.ChiefMinister);
                cmd.Parameters.AddWithValue("@AreaCode", state.AreaCode);
                cmd.ExecuteNonQuery();
            }
        }
        states.Add(state);
    }

    public void ChangePopulation(State state, int newPopulation)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            string query = "UPDATE States SET Population = @Population WHERE AreaCode = @AreaCode";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Population", newPopulation);
                cmd.Parameters.AddWithValue("@AreaCode", state.AreaCode);
                cmd.ExecuteNonQuery();
            }
        }

        state.Population = newPopulation;
        Console.WriteLine($"Population of {state.Name} changed to {newPopulation}.");
    }

    public void ChangeChiefMinister(State state, string newChiefMinister)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            string query = "UPDATE States SET ChiefMinister = @ChiefMinister WHERE AreaCode = @AreaCode";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ChiefMinister", newChiefMinister);
                cmd.Parameters.AddWithValue("@AreaCode", state.AreaCode);
                cmd.ExecuteNonQuery();
            }
        }

        state.ChiefMinister = newChiefMinister;
        Console.WriteLine($"Chief Minister of {state.Name} changed to {newChiefMinister}.");
    }

    public void DisplayTotalStates()
    {
        Console.WriteLine($"Total number of states: {State.TotalStates}");
    }
}
