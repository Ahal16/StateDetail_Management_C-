﻿using System;
using System.Collections.Generic;

public class State
{
    private static int totalStates = 0;
    private string name;
    private string capital;
    private int population;
    private string chiefMinister;
    private string areaCode;

    public State(string name, string capital, int population, string chiefMinister, string areaCode)
    {
        this.name = name;
        this.capital = capital;
        this.Population = population; // Use the property for validation
        this.chiefMinister = chiefMinister;
        this.areaCode = areaCode;
        totalStates++;
    }

    public string Name => name;
    public string Capital => capital;

    public int Population
    {
        get => population;
        set
        {
            if (value < 0) throw new ArgumentException("Population cannot be negative.");
            population = value;
        }
    }

    public string ChiefMinister
    {
        get => chiefMinister;
        set => chiefMinister = value;
    }

    public string AreaCode => areaCode;

    public static int TotalStates => totalStates;

    public static void DisplayMostPopulatedState(List<State> states)
    {
        if (states.Count == 0) throw new InvalidOperationException("No states available.");

        State mostPopulated = states[0];
        foreach (var state in states)
        {
            if (state.Population > mostPopulated.Population)
                mostPopulated = state;
        }

        Console.WriteLine($"Most Populated State: {mostPopulated.Name}, Population: {mostPopulated.Population}, Chief Minister: {mostPopulated.ChiefMinister}");
    }
}
